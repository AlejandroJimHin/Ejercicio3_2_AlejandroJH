package componente;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

import org.junit.jupiter.api.Test;

class ComponenteControllerTest {

	@Test
	void testInitialize() {
		Random random = new Random();
		int numeroAleatorio = random.nextInt(255) + 1;
		
		if (numeroAleatorio > 255 || numeroAleatorio < 0) {
			fail("Esta fuera de rango");
		}
		else {
			assertEquals(numeroAleatorio, numeroAleatorio);
		}
		
	}

}
