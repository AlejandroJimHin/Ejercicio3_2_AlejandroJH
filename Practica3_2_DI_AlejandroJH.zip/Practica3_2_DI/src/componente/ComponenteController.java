package componente;

import java.util.Random;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.transform.Rotate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ComponenteController {
	
	@FXML
	private TextField tf_texto;
	
	@FXML
	public Button bt_boton;
	
	@FXML
	public void initialize() {
		
		bt_boton.setOnAction(event -> {
			//Creamos un objeto de la clase Rotate.
			Rotate rotacion = new Rotate();
			
			//Aqui creamos la rotacion del tf_texto.
			rotacion.setAngle(45);
			rotacion.setPivotX(tf_texto.getHeight() / 2);
			rotacion.setPivotY(tf_texto.getWidth() / 2);
			
			//Aqui, agregamos lo parametros que hemos creado anteriormente.
			tf_texto.getTransforms().add(rotacion);
			
			//Creamos un objeto de la clase Random.
			Random random = new Random();
			
			//Generamos un numero desde 1 al 255.
			int numeroAleatorio1 = random.nextInt(255) + 1;
			int numeroAleatorio2 = random.nextInt(255) + 1;
			int numeroAleatorio3 = random.nextInt(255) + 1;
		
		    //Asignamos a los tres colores principales del RGB, el numero aleatorio.
		    int red = numeroAleatorio1;
		    int green = numeroAleatorio2;
		    int blue = numeroAleatorio3;

		    // Crear el estilo en formato CSS y agregarle los colores anteriores.
		    String style = String.format("-fx-background-color: rgb(%d, %d, %d);", red, green, blue);

		    // Aplicar el estilo al tf_texto.
		    tf_texto.setStyle(style);
		    
		});

		
		
		
	}
	
}
