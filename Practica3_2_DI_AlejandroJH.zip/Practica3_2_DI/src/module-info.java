module Practica3_2_DI {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.desktop;
	requires org.junit.jupiter.api;
	
	opens componente to javafx.graphics, javafx.fxml;
}
